from testai.AI import MinMax, AIMoveMinMaxEvalAlphaBeta, getVistCountMinMax, getVistCountQ, resetVistCountMinMax, resetVistCountQ, \
                AIMoveMinMaxEvalAlphaBetaOrder, resetSavedState,  \
                AIMoveMinMaxEvalAlphaBetaOrderQuiescensePruning,  \
                AIMoveMinMaxEvalAlphaBetaOrderQuiescensePruningNoCache, \
                AIMoveMinMaxEvalAlphaBetaOrderNoCache,  \
                AIMoveMinMaxEvalAlphaBetaOrderCacheQuiescensePruning, \
                resetBoardToRes,  \
                AIMoveMinMaxEvalAlphaBetaOrderNoCacheDepthOne, \
                AIMoveMinMaxEvalAlphaBetaShuffle, \
                AIMoveMinMaxEvalAlphaBetaOrderPiece, \
                AIMoveMinMaxEvalAlphaBetaOrderByPieceQuiescensePruning, \
                AIMoveMinMaxEvalAlphaBetaQuiescensePruning, \
                AIMoveMinMaxEvalAlphaBetaCacheQuiescensePruning, \
                AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0, \
                AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0Ordered, \
                AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0ProvideMoves, \
                MinMaxRecalMovesDepth0board
                    
                
from testai.score_board import resetBluredCache, bestMovesOfSameTopScore, topSame, topSameRes
from testai.board import Board
from testai.path_finding import all_possible_moves
import math
import time


#This is our file that we conducted test on our AI's to see what changes
#increased the speed and what lowered the nodes visted


def testFunc(func, board, name, depth):
    resetVistCountQ()
    resetVistCountMinMax()
    resetSavedState()
    resetBoardToRes()
    resetBluredCache()
    
    print(name)
    start = time.time()
    move = func(board.copy(), 0, True, -math.inf, math.inf, depth)
    end = time.time()

  
    

    print("Score: ", move[0])
    print("Move: ", move[1])
    print("Time Took:", "{:.2f}".format(end - start), " seconds")
    print("Visted in Min Max: ", getVistCountMinMax())
    print("Visted in Quiesense Search", getVistCountQ())
    print("Total Visited", getVistCountMinMax() + getVistCountQ())
    print("________________________________________")




def test(boardData):

    board = Board(boardData, "white")
    board.print()   
    print("________________________________________")

    depth = 2
        
    testFunc(AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0Ordered, board, "Min Max Alpha Beta Pruning Blowup Ordered", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0, board, "Min Max Alpha Beta Pruning Blowup", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaQuiescensePruning, board, "Min Max Alpha Beta Pruning, Quiescence Search Pruning with Cache", depth)

    testFunc(MinMax, board, "Min Max", depth)
    
    testFunc(AIMoveMinMaxEvalAlphaBeta, board, "Min Max Alpha Beta Pruning", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaShuffle, board, "Min Max Alpha Beta Pruning Shuffle", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaOrderNoCacheDepthOne, board, "Min Max Alpha Beta Pruning with order only at depth 1", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaOrderNoCache, board, "Min Max Alpha Beta Pruning with Ordering by move, Quiescence Search", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaOrderPiece, board, "Min Max Alpha Beta Pruning with Ordering by Piece, Quiescence Search", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaOrder, board, "Min Max Alpha Beta Pruning with Ordering, Quiescence Search With Cache", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaOrderQuiescensePruningNoCache, board, "Min Max Alpha Beta Pruning Ordering, Quiescence Search with Pruning", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaOrderQuiescensePruning, board, "Min Max Alpha Beta Pruning Ordering, Quiescence Search Pruning with Cache", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaOrderByPieceQuiescensePruning, board, "Min Max Alpha Beta Pruning Ordering By Piece, Quiescence Search Pruning with Cache", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaQuiescensePruning, board, "Min Max Alpha Beta Pruning, Quiescence Search Pruning with Cache", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaOrderCacheQuiescensePruning, board, "Min Max Alpha Beta Pruning Ordering Cache, Quiescence Search Pruning with Cache", depth)

    testFunc(AIMoveMinMaxEvalAlphaBetaCacheQuiescensePruning, board, "Min Max Alpha Beta Pruning Cache, Quiescence Search Pruning with Cache", depth)






def testBoards():
    black = [(1,0,7), (1,1,7),   (1,3,7), (1,4,7),   (1,6,7), (1,7,7),
             (1,0,6), (1,1,6),   (1,3,6), (1,4,6),   (1,6,6), (1,7,6)]

    white = [(1,0,1), (1,1,1),   (1,3,1), (1,4,1),   (1,6,1), (1,7,1),
             (1,0,0), (1,1,0),   (1,3,0), (1,4,0),   (1,6,0), (1,7,0)]
    test({"white":white, "black":black})

    black = [(1,0,7), (1,1,7),   (1,3,7), (1,4,7),   (1,6,7), (1,7,7),
             (1,0,6), (1,1,6),   (1,3,6), (1,4,6),   (1,6,6), (1,7,6)]

    white = [(1,0,1), (1,1,1),   (1,3,1), (2,4,3),   (1,6,1), (1,7,1),
             (1,0,0), (1,1,0),   (1,3,0),    (1,6,0), (1,7,0)]
    test({"white":white, "black":black})
    

    black = [(1,0,7), (1,1,7),   (1,3,7),             (1,6,7), (1,7,7),
             (1,0,6), (4,1,2),                        (1,6,6), (1,7,6)]

    white = [(1,0,1), (1,1,1),    (3,4,5),   (1,6,1), (1,7,1),
             (1,0,0), (1,1,0),   (1,3,0),    (1,6,0), (1,7,0)]
    test({"white":white, "black":black})
     

    black = [         (1,5,3),   (1,3,7), (1,4,7),   (1,6,7), (1,7,7),
             (2,0,2), (1,3,4),   (1,3,6), (1,4,6),   (1,6,6), (1,7,6)]

    white = [(1,0,1), (1,1,1),   (2,3,1),   (4,7,4),
             (1,0,0), (1,1,0),   (1,3,0), (1,4,0),   ]
    test({"white":white, "black":black})


    black = [         (1,5,4),   (1,3,0), (1,4,0),   (1,6,0), (1,7,0),
             (2,0,5), (1,3,3),   (1,3,1), (1,4,1),   (1,6,1), (1,7,1)]

    white = [(1,0,6), (1,1,6),   (2,3,6),   (4,7,3),
             (1,0,7), (1,1,7),   (1,3,7), (1,4,7),   ]
    test({"white":white, "black":black})







