from testai.board import Board
from testai.path_finding import nextTo, isInsideBoard, all_possible_moves, possible_moves
import numpy as np
import random 
from scipy.ndimage import gaussian_filter

def bestPieces(board: Board, bmap):
    pieces = []
    for pos in board:
        if(board[pos].isMyToken):
            pieces.append((rankPiece(board[pos].numTokens, pos, bmap), pos))
    
    pieces.sort(key=lambda x:x[0], reverse=True)
    return pieces

def myPieces(board: Board):
    pieces = []
    for pos in board:
        if(board[pos].isMyToken):
            pieces.append(pos)
    return pieces
    
def topSame(moves):
    topSame = []
    topRes = moves[0][0]
    for (res, move) in moves:
        if(topRes == res):
            topSame.append(move)
    return topSame

def topSameRes(moves):
    topSame = []
    topRes = moves[0][0]
    for (res, move) in moves:
        if(topRes == res):
            topSame.append((res,move))
    return topSame

def bestMovesOfSameTopScore(board: Board, movess):
    bmap = createbmap(board)
    topSame = []
    topRes = movess[0][0]
    for (res, moves) in movess:
        move = moves[0]
        if(topRes == res):
            if(move[0]==None):
                newres = scoreBlowUp(board, move[1])
            else:
                newres = rankPiece(board.amountOfTokensAtDestination(move), move[2], bmap)
            
            topSame.append((res, moves, newres))
    
    topSame.sort(key=lambda x: x[2], reverse = True)
    return topSame


def bestMoveOfSameTopScore(board: Board, moves):
    bmap = createbmap(board)
    topSame = []
    topRes = moves[0][0]
    for (res, move) in moves:
        if(topRes == res):
            if(move[0]==None):
                newres = scoreBlowUp(board, move[1])
            else:
                newres = rankPiece(board.amountOfTokensAtDestination(move), move[2], bmap)
            
            topSame.append(((res, move), newres))
    
    topSame.sort(key=lambda x: x[1], reverse = True)
    return topSame[0][0]

def bestMoves(board: Board):
    bmap = createbmap(board)
    #pieces = bestPieces(board, bmap)[:3]
    pieces = myPieces(board)
    moves = []
    for pos in pieces:
        if(board.nearby_enemy(pos)):
            moves.append((scoreBlowUp(board, pos), (None, pos, None)))



        for move in possible_moves(board[pos].numTokens, pos, board):
            #board.update_board(move[1], move[2], move[0])
            #board.print()
            res = rankPiece(board.amountOfTokensAtDestination(move), move[2], bmap)
            moves.append((res, move))
    
    moves.sort(key=lambda x:x[0], reverse=True)
    m = []
    for move in moves:
        m.append(move[1])
    return m

def bestMovesByPiece(board: Board):
    bmap = createbmap(board)
    pieces = bestPieces(board, bmap)
    moves = []
    for (_,pos) in pieces:
        if(board.nearby_enemy(pos)):
               moves.append((None, pos, None))
        
        for move in possible_moves(board[pos].numTokens, pos, board):
            moves.append(move)

    return moves


def topMove(board: Board):
    bmap = createbmap(board)
    pieces = bestPieces(board, bmap)[:1]
    #pieces = myPieces(board)
    moves = []
    for (_,pos) in pieces:
        if(board.nearby_enemy(pos)):
               moves.append((scoreBlowUp(board, pos), (None, pos, None)))
        
        for move in possible_moves(board[pos].numTokens, pos, board):
           res = rankPiece(board.amountOfTokensAtDestination(move), move[2], bmap)
           moves.append((res, move))
    
    moves.sort(key=lambda x:x[0], reverse=True)
    m = []
    for move in moves:
        m.append(move[1])
    return m[:1]

def blowUps(board: Board):
    pieces = myPieces(board)
    moves = []
    for pos in pieces:
        if(board.nearby_enemy(pos)):
               moves.append((None, pos, None))

    return moves

def bigstack(board: Board):
    pieces = myPieces(board)
    moves = []
    for pos in pieces:
        board[pos].numTokens >= 4
        stack_moves = possible_moves(board[pos].numTokens, pos, board)
        for move in stack_moves:
            if(board.nearby_enemy(move[2])):
               moves.append(move)
    return moves

def create_islands(board:Board):
    """
    Input  Board

    Output: A dictionary of islands with the key being an integer representing the island id
            and the value being a list of tuples, representing the pieces in that island.

            Example: {0: [(3, 5)], 1: [(4, 3)], 2: [(0, 7)], 3: [(4, 1)], 4: [(6, 2), (7, 3)]}
            means there are 5 islands, and island 4 has two pieces in it: (6, 2) and (7, 3)
    """
    islands = {}
    island_no = 0
    for pos in board:
        tile = board[pos]
        if not pos in islands:
            recurseIslands(island_no, pos, board, islands)
            island_no += 1

    ret_islands = {}
    for pos in islands:
        if islands[pos] not in ret_islands:
            ret_islands[islands[pos]] = [pos]
        else:
            ret_islands[islands[pos]].append(pos)
    return ret_islands

def recurseIslands(id, pos, board, islands):
    islands[pos] = id
    for x in range(-1,2):
        for y in range(-1,2):
            neighborPos = (pos[0]+x,pos[1]+y)
            if(neighborPos in board and not neighborPos in islands):
                recurseIslands(id, neighborPos, board, islands)


def islandSize(pos, board, islands):
    islands.add(pos)
    for x in range(-1,2):
        for y in range(-1,2):
            neighborPos = (pos[0]+x,pos[1]+y)
            if(neighborPos in board and not neighborPos in islands):
                islandSize(neighborPos, board, islands)
    return islands

def blowUpMap(board:Board, isMyToken, islands):
    blowUpMap = np.zeros((8,8), dtype=float)

    for id in islands:
        l = 0
        for pos in islands[id]:
            if(board[pos].isMyToken != isMyToken):
                l += board[pos].numTokens
            #else:
            #    l -= board[pos].numTokens

        for pos in islands[id]:
            if(board[pos].isMyToken != isMyToken):
                blowUpMap[pos[0]][pos[1]] = l

    return blowUpMap #gaussian_filter(blowUpMap, sigma=0.9)

   

def movementMap(board: Board, isMyToken = True):
    moveMap = np.zeros((8,8))
    
    for pos in board:
        tile = board[pos]
        if(tile.isMyToken == isMyToken):
            moveMap[pos[0]][pos[1]] = tile.numTokens

    blured = gaussian_filter(moveMap, sigma = 0.9, mode="constant", cval=0)
   
    for x in range(8):
        for y in range(8):
            if(moveMap[x][y] > 0):
                blured[x][y] = 3
    return blured

def movementMapBoth(board: Board, isMyToken = True):
    moveMap = np.zeros((8,8))
    
    for pos in board:
        tile = board[pos]
        if(tile.isMyToken == isMyToken):
            moveMap[pos[0]][pos[1]] = tile.numTokens
        else: 
            moveMap[pos[0]][pos[1]] = -tile.numTokens

    blured = gaussian_filter(moveMap, sigma = 0.9, mode="constant", cval=0)
   
    for x in range(8):
        for y in range(8):
            if(moveMap[x][y] > 0):
                blured[x][y] = 3
            if(moveMap[x][y] < 0):
                blured[x][y] = -3
    return blured


def blowUpAvailableEval(board: Board, bmap, isMyToken = True):
    mmap = movementMap(board, isMyToken)
    #np.set_printoptions(precision=3)
    #np.set_printoptions(suppress=True)
    #board.print()
    # print(mmap)
    # print(bmap)
    #print()
    return np.sum(np.multiply(bmap,mmap))

def enemiesVsPlayerHeuristic(board: Board):
    white = 1
    black = 1
    for pos in board.tiles:
        if(board[pos].is_enemy()):
            black = black + board[pos].numTokens
        else:
            white = white + board[pos].numTokens
    if(black == 1 and white != 1):
        return 10000000
    if(white == 1 and black != 1):
        return -10000000
    if(white == 1 and black == 1):
        return 0
    return white/black

def availableMovesHeuristic(board: Board):
    friendly = len(all_possible_moves(board)) + 1
    board.flipPlayer()
    enemy = len(all_possible_moves(board)) + 1
    board.flipPlayer()

    return friendly/enemy

def scoreBlowUp(board: Board, pos):
    board = board.copy()
    before = enemiesVsPlayerHeuristic(board)
    board.update_explosion(pos)
    after = enemiesVsPlayerHeuristic(board)
    return (after-before)*100

boardScores = {}

def blowUpAvailableEvalBoth1(board: Board):
    # global boardScores
    # bhash = board.to_hashable()
    # if(bhash in boardScores):
    #     return boardScores[bhash]
    # else:
    #     #score = random.randint(0,100)
        

    score = enemiesVsPlayerHeuristic(board)*100
    if(board.no_enemies()):
        score *= 3
    islands = create_islands(board)
    bmap = blowUpMap(board, True, islands)



    zeros = np.zeros((8,8))
    score += (blowUpAvailableEval(board, np.maximum(zeros, bmap), True) - 
        blowUpAvailableEval(board, np.maximum(zeros, np.negative(bmap)), False))
    #mmap = movementMapBoth(board)
    
    #print(mmap)

    #score += np.sum(np.multiply(bmap, mmap)) 
    #boardScores[bhash] = score
    return score

global enemyMMap

def newEnemyMoveMap(board: Board):
    global enemyMMap
    enemyMMap = movementMap(board, False)

def blowUpAvailableEvalBoth(board: Board):
    global boardScores
    bhash = board.to_hashable()
    if(bhash in boardScores):
        return boardScores[bhash]
    else:
        #score = random.randint(0,100)
        

        score = enemiesVsPlayerHeuristic(board)*100
        if(board.no_enemies()):
            score *= 3
        islands = create_islands(board)
        bmap = blowUpMap(board, True, islands)



        zeros = np.zeros((8,8))
        score += blowUpAvailableEval(board, np.maximum(zeros, bmap), True) -  \
            np.sum(np.multiply(np.maximum(zeros, np.negative(bmap)), enemyMMap))
        #mmap = movementMapBoth(board)
    
        #score += np.sum(np.multiply(bmap, mmap)) 
        boardScores[bhash] = score
        return score
    # islands = create_islands(board)
    # return (blowUpAvailableEval(board, islands, True) - blowUpAvailableEval(board, islands, False))+(enemiesVsPlayerHeuristic(board)*100)

def createbmap(board: Board):
    islands = create_islands(board)
    bmap = blowUpMap(board, True, islands)
    zeros = np.zeros((8,8))
    bmap = np.maximum(zeros, bmap)
    return bmap



bluredCache = {}
def resetBluredCache():
    global bluredCache
    bluredCache = {}

def rankPiece(numTokens, pos, bmap):
    global bluredCache
    key = (numTokens, pos)
    if(not key in bluredCache):
        moveMap = np.zeros((8,8))
        
        moveMap[pos[0]][pos[1]] = numTokens
        blured = gaussian_filter(moveMap, sigma = numTokens, mode="constant", cval=0)
        
        #blured[pos[0]][pos[1]] = 6/(numTokens**4)
        bluredCache[key] = blured
    else:
        blured = bluredCache[key]

    # np.set_printoptions(precision=0)
    # np.set_printoptions(suppress=True)
    
    # print(np.flipud(np.transpose(bmap)).astype(int))
    # np.set_printoptions(precision=2)
    # np.set_printoptions(suppress=True)
    # print(np.flipud(np.transpose(blured)))
    

    return np.sum(np.multiply(blured, bmap))


def customEvaluation(board: Board):
    score = enemiesVsPlayerHeuristic(board) + availableMovesHeuristic(board)
    return score

def rankBoard(board: Board):
    score = enemiesVsPlayerHeuristic(board)*1000
    return score
    islands = create_islands(board)

    # sumRatio = 0
    # for id in islands:
    #     island = islands[id]
    #     numFriend = 0
    #     numEnemey = 0
    #     for pos in island:
    #         if(board[pos].isMyToken):
    #             numFriend += board[pos].numTokens
    #         else:
    #             numEnemey += board[pos].numTokens
    #     if(numEnemey == 0):
    #        pass
    #        sumRatio -= len(island)
    #     elif(numFriend == 0):
    #         pass
    #         sumRatio += len(island)
    #     else:
    #         #sumRatio += (numEnemey-numFriend)*3
    #         if(numEnemey > numFriend):
    #             sumRatio += (numEnemey/numFriend)*3
    #         else:
    #             sumRatio -= (numFriend/numEnemey)*3

    # score += sumRatio
    #return score + random.random()
    bmap = blowUpMap(board, True, islands)
    zeros = np.zeros((8,8))

    bmap1 = np.maximum(zeros, bmap)

    board.flipPlayer()
    bmap2 = np.maximum(zeros, np.negative(bmap))
    board.flipPlayer()

    # np.set_printoptions(precision=3)
    # np.set_printoptions(suppress=True)
    #board.print()
    # print(bmap)
    # print(bmap2)

    for pos in board:
        if(board[pos].isMyToken):
            score += rankPiece(board[pos].numTokens, pos, bmap1)
        else:
            score -= rankPiece(board[pos].numTokens, pos, bmap2)

    
    

    return score
   
def rankPieceDefensive(numTokens, pos, bmap):   

    moveMap = np.zeros((8,8))
    moveMap[pos[0]][pos[1]] = 1
    blured = gaussian_filter(moveMap, sigma = 1, mode="constant", cval=0)

    # np.set_printoptions(precision=3)
    # np.set_printoptions(suppress=True)
    # print(blured)
   
    # if(numTokens == 2):
    #     i = 0

    return np.sum(np.multiply(blured, bmap))
   

def evalMega(board: Board):
    score = enemiesVsPlayerHeuristic(board)*300
    stackScore = 0
    for pos in board:
        if(board[pos].isMyToken):
            stackScore += board[pos].numTokens*2

    

    return score + stackScore

    
# def get_moves_increase_ally_islands(board: Board) -> list:
    # moves = movementMoves(board)
    # ally_islands = create_islands(board)
    # num_ally_islands = len(ally_islands)
    # retained_moves = []
    # for move in moves:
    #     board.update_board(move[1], move[2], move[0])
    #     temp_islands = create_islands(board)
    #     board.update_board(move[2], move[1], move[0])
    #     if(len(temp_islands) > num_ally_islands):
    #         retained_moves.append((len(temp_islands)-num_ally_islands,  move))

    # retained_moves.sort(key=lambda x:x[0])
    # return retained_moves