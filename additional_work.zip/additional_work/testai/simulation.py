from.player import ExamplePlayer, AnotherPlayer

def simulate():
    player_white = ExamplePlayer("black")
    player_black = AnotherPlayer("white")

    player_black.board.print()

    player_curr, player_next = (player_white, player_black)
    move_no = 0
    while(not (player_curr.board.no_enemies() or player_curr.board.no_my_tokens())) or move_no >  250:
        move_no += 1
        action = player_curr.action()
        print(f"{player_curr.colour}s action: {action}")
        player_curr.update(player_curr.colour, action)
        player_next.update(player_next.colour, action)
        player_curr.board.print()


        if(player_curr.board.no_enemies() and player_curr.board.no_my_tokens()):
            print(f"Draw in {move_no} moves")
        if(player_curr.board.no_enemies()):
            print(f"{player_curr.colour} wins in {move_no} moves")
        if(player_curr.board.no_my_tokens()):
            print(f"{player_curr.colour} wins in {move_no} moves")

        player_curr, player_next = (player_next, player_curr)

