from testai.test import testBoards

testBoards()