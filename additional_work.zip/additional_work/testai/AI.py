from testai.board import Board
from testai.path_finding import all_possible_moves, possible_moves,vector_addition,nextTo
from testai.score_board import bestMoves,topMove,bestMoveOfSameTopScore, bigstack, bestMovesByPiece, blowUps, createbmap, blowUpAvailableEvalBoth1, rankBoard, enemiesVsPlayerHeuristic, customEvaluation
import operator
import math
import numpy as np
import random

import copy
import time

book = {}
 
savedStates = {}
def resetSavedState():
    global savedStates
    savedStates = {}

vistCountMinMax = 0
def getVistCountMinMax():
    return vistCountMinMax

def resetVistCountMinMax():
    global vistCountMinMax
    vistCountMinMax = 0

vistCountQ = 0
def getVistCountQ():
    return vistCountQ

def resetVistCountQ():
    global vistCountQ
    vistCountQ = 0
 
boardsToRes = {}
def resetBoardToRes():
    global boardsToRes
    boardsToRes = {}


def QuiescenceSearchNoCache(board: Board, depth, isMax:bool):
    global vistCountQ
    vistCountQ += 1
    
    if(not isMax):
        board.flipPlayer()
    bestRes = rankBoard(board)
    if(not isMax):
        board.flipPlayer()

    moves = blowUps(board)
    #if no more blowups evaulate board
    if(len(moves) == 0):
        return bestRes


    for move in moves:        
        moveBoard = board.copy()
        moveBoard.update_board(move[1],move[2], move[0])

        moveBoard.flipPlayer()
        res = QuiescenceSearchNoCache(moveBoard, depth+1, not isMax)

        #if i find out that min blows itself up and my score increases, then this isnt a valid move
        #if i found out that min blows up and my score decreases then it will choose this
        
        if(isMax):
            if(res > bestRes):
                #if i am max, then always grab the best res as the min
                bestRes = res
                


        #if i am a min and it is lower, then there best result, ill take it
        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < bestRes):
                bestRes = res

    savedStates[board.to_hashable()] = bestRes
    return bestRes



def QuiescenceSearchStack(board: Board, depth, isMax:bool):
    global savedStates
    bhash = board.to_hashable()
    if bhash in savedStates:
        return savedStates[bhash]

    global vistCountQ
    vistCountQ += 1
    
    if(not isMax):
        board.flipPlayer()
    bestRes = rankBoard(board)
    if(not isMax):
        board.flipPlayer()

    moves = blowUps(board)
    if(depth == 0):
        moves.extend(bigstack(board))
    
    #if no more blowups evaulate board
    if(len(moves) == 0 or depth > 3):
        return bestRes
   
    for move in moves:        
        moveBoard = board.copy()
        moveBoard.update_board(move[1],move[2], move[0])

        moveBoard.flipPlayer()
        res = QuiescenceSearch(moveBoard, depth+1, not isMax)

        #if i find out that min blows itself up and my score increases, then this isnt a valid move
        #if i found out that min blows up and my score decreases then it will choose this
        
        if(isMax):
            if(res > bestRes):
                #if i am max, then always grab the best res as the min
                bestRes = res
                


        #if i am a min and it is lower, then there best result, ill take it
        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < bestRes):
                bestRes = res

    savedStates[board.to_hashable()] = bestRes
    return bestRes

def QuiescenceSearch(board: Board, depth, isMax:bool):
    global savedStates
    bhash = board.to_hashable()
    if bhash in savedStates:
        return savedStates[bhash]

    global vistCountQ
    vistCountQ += 1
    
    if(not isMax):
        board.flipPlayer()
    bestRes = rankBoard(board)
    if(not isMax):
        board.flipPlayer()

    moves = blowUps(board)
    
    #if no more blowups evaulate board
    if(len(moves) == 0 or depth > 3):
        return bestRes
   
    for move in moves:        
        moveBoard = board.copy()
        moveBoard.update_board(move[1],move[2], move[0])

        moveBoard.flipPlayer()
        res = QuiescenceSearch(moveBoard, depth+1, not isMax)

        #if i find out that min blows itself up and my score increases, then this isnt a valid move
        #if i found out that min blows up and my score decreases then it will choose this
        
        if(isMax):
            if(res > bestRes):
                #if i am max, then always grab the best res as the min
                bestRes = res
                


        #if i am a min and it is lower, then there best result, ill take it
        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < bestRes):
                bestRes = res

    savedStates[board.to_hashable()] = bestRes
    return bestRes

def BlowUp(board: Board, isMax:bool):
    global vistCountQ
    vistCountQ += 1
    
    moveBoard = board.copy()
    moves = blowUps(moveBoard)
    while(len(moves) > 0):
        move = moves[0]
        moveBoard.update_board(move[1],move[2], move[0])
        moves = blowUps(moveBoard)
    
    if(not isMax):
        moveBoard.flipPlayer()
    bestRes = rankBoard(moveBoard)
    #bestRes = customEvaluation(board)
    return bestRes
    
   
 
def QuiescenceSearchPruning(board: Board, depth, isMax:bool, minRes, maxRes):
    global savedStates
    bhash = board.to_hashable()
    if bhash in savedStates:
        return savedStates[bhash]

    global vistCountQ
    vistCountQ += 1
    
    if(not isMax):
        board.flipPlayer()
    bestRes = rankBoard(board)
    if(not isMax):
        board.flipPlayer()

    moves = blowUps(board)
    #if no more blowups evaulate board
    if(len(moves) == 0):
        return bestRes


    for move in moves:        
        moveBoard = board.copy()
        moveBoard.update_board(move[1],move[2], move[0])

        moveBoard.flipPlayer()
        res = QuiescenceSearchPruning(moveBoard, depth+1, not isMax, minRes, maxRes)

        #if i find out that min blows itself up and my score increases, then this isnt a valid move
        #if i found out that min blows up and my score decreases then it will choose this
        
        if(isMax):
            if(res > bestRes):
                #if i am max, then always grab the best res as the min
                bestRes = res
                minRes = res
            
            if(minRes >= maxRes):
                break


        #if i am a min and it is lower, then there best result, ill take it
        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < bestRes):
                bestRes = res
                maxRes = res

            
            if(minRes >= maxRes):
                break

    savedStates[board.to_hashable()] = bestRes
    return bestRes

def QuiescenceSearchPruningNoCache(board: Board, depth, isMax:bool, minRes, maxRes):
    # global savedStates
    # bhash = board.to_hashable()
    # if bhash in savedStates:
    #     return savedStates[bhash]

    global vistCountQ
    vistCountQ += 1
    
    if(not isMax):
        board.flipPlayer()
    bestRes = rankBoard(board)
    if(not isMax):
        board.flipPlayer()

    moves = blowUps(board)
    #if no more blowups evaulate board
    if(len(moves) == 0):
        return bestRes


    for move in moves:        
        moveBoard = board.copy()
        moveBoard.update_board(move[1],move[2], move[0])

        moveBoard.flipPlayer()
        res = QuiescenceSearchPruningNoCache(moveBoard, depth+1, not isMax, minRes, maxRes)

        #if i find out that min blows itself up and my score increases, then this isnt a valid move
        #if i found out that min blows up and my score decreases then it will choose this
        
        if(isMax):
            if(res > bestRes):
                #if i am max, then always grab the best res as the min
                bestRes = res
                minRes = res
            
            if(minRes >= maxRes):
                    break


        #if i am a min and it is lower, then there best result, ill take it
        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < bestRes):
                bestRes = res
                maxRes = res

            
            if(minRes >= maxRes):
                    break

    savedStates[board.to_hashable()] = bestRes
    return bestRes



def AIMoveMinMaxEvalAlphaBetaOrderNoCache(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearchNoCache(board, depth, isMax), None)

    moves = bestMoves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaOrderNoCache(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)

def AIMoveMinMaxEvalAlphaBetaOrderNoCacheDepthOne(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearchNoCache(board, depth, isMax), None)

    if(depth == 0):
        moves = bestMoves(board)
    else:
        moves = all_possible_moves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaOrderNoCacheDepthOne(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)

def AIMoveMinMaxEvalAlphaBetaOrderQuiescensePruningNoCache(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearchPruningNoCache(board, depth, isMax, minRes, maxRes), None)

    moves = bestMoves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaOrderQuiescensePruningNoCache(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)


def AIMoveMinMaxEvalAlphaBetaOrderQuiescensePruning(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearchPruning(board, depth, isMax, minRes, maxRes), None)

    moves = bestMoves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaOrderQuiescensePruning(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)

def AIMoveMinMaxEvalAlphaBetaOrderByPieceQuiescensePruning(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearchPruning(board, depth, isMax, minRes, maxRes), None)

    moves = bestMovesByPiece(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaOrderByPieceQuiescensePruning(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)

def AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (BlowUp(board, isMax), None)

    moves = all_possible_moves(board)   
    #moves = bestMoves(board)

    rankedMoves = []
    for move in moves:
        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaQuiescensePruning(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])

        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res

            if(minRes >= maxRes):
                break

        
        rankedMoves.append((res, move))

    rankedMoves.sort(key = lambda x:x[0], reverse = True)
    moves = bestMoveOfSameTopScore(board, rankedMoves)
    return moves

def AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0Ordered(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (BlowUp(board, isMax), None)

    #moves = all_possible_moves(board)   
    moves = bestMoves(board)

    rankedMoves = []
    for move in moves:
        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaQuiescensePruningOrdered(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])

        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res

            if(minRes >= maxRes):
                break

        
        rankedMoves.append((res, move))

    rankedMoves.sort(key = lambda x:x[0], reverse = True)
    moves = bestMoveOfSameTopScore(board, rankedMoves)
    return moves


def MinMaxRecalMovesDepth0board(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearch(board, depth, isMax), [])

    moves = all_possible_moves(board)

    rankedMoves = []
    for move in moves:
        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, chosenMoves) = MinMaxRecalMoves(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  
        chosenMoves.append(move)
        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])

        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res

        
        rankedMoves.append((res, chosenMoves))

    rankedMoves.sort(key = lambda x:x[0], reverse = isMax)
    return rankedMoves

def MinMaxRecalMoves(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearch(board, depth, isMax), [])

    moves = all_possible_moves(board)

    bestMoves = []
    for move in moves:
        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, chosenMoves) = MinMaxRecalMoves(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  
        chosenMoves.append(move)
        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])

        if(isMax):
            if(res >= minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMoves = chosenMoves

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res <= maxRes):
                maxRes = res
                bestMoves = chosenMoves
                
            if(minRes >= maxRes):
                break

        
        
    return (res, bestMoves)


def AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0ProvideMoves(board: Board, depth, isMax:bool, minRes, maxRes, cutoff, moves):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearch(board, depth, isMax), None)

    bestMove = None
    rankedMoves = []
    for move in moves:
        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaQuiescensePruning(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])

        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move
                bestRes = res

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move
                bestRes = res

        
        rankedMoves.append((res, move))

    rankedMoves.sort(key = lambda x:x[0], reverse = True)
    return rankedMoves

def QuiescenceSearchTest(board: Board, depth, isMax: book, minRes, maxRes, cutoff=2):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (BlowUp(board, isMax), None)

    moves = all_possible_moves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        if(depth == 2 and move[1] == (6,5)):
            g = 0

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = QuiescenceSearchTest(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    bestRes = None
    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes
    
    if(bestMove == None):
        bestRes = BlowUp(board, isMax)
        if(bestRes < 1000):
            g = 0
        

    
    return (bestRes, bestMove)

def AIMoveMinMaxEvalAlphaBetaQuiescensePruning(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        # for pos in board.tiles:
        #     if board.tiles[pos].numTokens >= 4:
        #         print(pos, board.tiles[pos])
        #         # sleep(10)
        #         return QuiescenceSearchTest(board, 1, not isMax, minRes, maxRes, )
        return (BlowUp(board, isMax), None)

    moves = all_possible_moves(board)
    #moves = bestMoves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaQuiescensePruning(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move


        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

        if(minRes >= maxRes):
            break


    bestRes = None
    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes
    
    if(bestMove == None):
        bestRes = BlowUp(board, isMax)
        

    
    return (bestRes, bestMove)



def AIMoveMinMaxEvalAlphaBetaQuiescensePruningOrdered(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        # for pos in board.tiles:
        #     if board.tiles[pos].numTokens >= 4:
        #         print(pos, board.tiles[pos])
        #         # sleep(10)
        #         return QuiescenceSearchTest(board, 1, not isMax, minRes, maxRes, )
        return (BlowUp(board, isMax), None)

    #moves = all_possible_moves(board)
    moves = bestMoves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaQuiescensePruningOrdered(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move


        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

        if(minRes >= maxRes):
            break


    bestRes = None
    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes
    
    if(bestMove == None):
        bestRes = BlowUp(board, isMax)
        

    
    return (bestRes, bestMove)



def AIMoveMinMaxEvalAlphaBetaOrderCacheQuiescensePruning(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearchPruning(board, depth, isMax, minRes, maxRes), None)

    moves = bestMoves(board)

    bestMove = None
    for move in moves:       

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


        atDepth = math.inf
        bhash = moveBoard.to_hashable()
        if(bhash in boardsToRes):
            (res, atDepth) = boardsToRes[bhash]

        if(atDepth > depth):
            moveBoard.flipPlayer()
            (res, _) = AIMoveMinMaxEvalAlphaBetaOrderCacheQuiescensePruning(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
            moveBoard.flipPlayer()
            boardsToRes[bhash] = (res, depth)
                  
        # moveBoard.flipPlayer()            
        # (res, _) = AIMoveMinMaxEvalAlphaBetaOrderCacheQuiescensePruning(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        # moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)

def AIMoveMinMaxEvalAlphaBetaCacheQuiescensePruning(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearchPruning(board, depth, isMax, minRes, maxRes), None)

    moves = all_possible_moves(board)

    bestMove = None
    for move in moves:       

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


        atDepth = math.inf
        bhash = moveBoard.to_hashable()
        if(bhash in boardsToRes):
            (res, atDepth) = boardsToRes[bhash]

        if(atDepth > depth):
            moveBoard.flipPlayer()
            (res, _) = AIMoveMinMaxEvalAlphaBetaCacheQuiescensePruning(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
            moveBoard.flipPlayer()
            boardsToRes[bhash] = (res, depth)
                  
        # moveBoard.flipPlayer()            
        # (res, _) = AIMoveMinMaxEvalAlphaBetaOrderCacheQuiescensePruning(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        # moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)


def AIMoveMinMaxEvalAlphaBetaOrder(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearch(board, depth, isMax), None)

    moves = bestMoves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaOrder(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)


def AIMoveMinMaxEvalAlphaBetaOrderPiece(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearch(board, depth, isMax), None)

    moves = bestMovesByPiece(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaOrderPiece(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)


def AIMoveMinMaxEvalAlphaBetaShuffle(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearch(board, depth, isMax), None)

    moves = all_possible_moves(board)
    random.shuffle(moves)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBetaShuffle(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)


# depth current depth
# minRes = alpha
#maxRes = beta
#cutoff = depth terminate search
def op_alpha_beta(board: Board, cutoff_depth=3):

    def max_value(board: Board, alpha, beta, depth, max_depth=cutoff_depth):
        colour = board.myColour
        if depth == max_depth:
            return rankBoard(board), None
        v = -np.inf
        moves = all_possible_moves(board)
        best_move = None
        for move in moves:
            copy_board =board.copy()
            copy_board.update(move)
            score_move, _ = min_value(copy_board, alpha, beta, depth+1, max_depth)
            v = max(v, score_move)

            if v == score_move:
                best_move = move
            if v >= alpha:
                return v, best_move
            alpha = max(alpha, v)
        return v, best_move
    
    def min_value(board: Board, alpha, beta, depth, max_depth=cutoff_depth):
        colour = board.myColour
        if depth == max_depth:
            return rankBoard(board), None
        v = np.inf
        best_move = None
        moves = all_possible_moves(board)
        for move in moves:
            copy_board = board.copy()
            copy_board.update(move)
            score_move, _ = max_value(copy_board, alpha, beta, depth+1, max_depth)
            v = min(v, score_move)
            if v == score_move:
                best_move = move
            if v <= alpha:
                return v, best_move
            beta = min(beta, v)
        return v, best_move

    v, move = max_value(board, -np.inf, np.inf, 0 , cutoff_depth)
    return move


def AIMoveMinMaxEvalAlphaBeta(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearch(board, depth, isMax), None)

    moves = all_possible_moves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
     
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = AIMoveMinMaxEvalAlphaBeta(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        #if(depth == 0):
        #   print(move, res)

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])
        
        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move
                bestRes = res

            #if i get say a 3 and my min parent already has a max 2
            #then i will never always give him anything less than 3
            #which is greater than 2, so he will always chose the 2 option
            if(minRes >= maxRes):
                break

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move
                bestRes = res

            #if i get say a 2 and my max parent already has a min 3
            #then i will never give him any better, thus quit
            if(minRes >= maxRes):
                break


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)




def MinMax(board: Board, depth, isMax:bool, minRes, maxRes, cutoff):
    global vistCountMinMax
    vistCountMinMax += 1
    # if(board.to_hashable() in book):
    #   return book[board.to_hashable()]

    if(depth > cutoff):
        return (QuiescenceSearch(board, depth, isMax), None)

    moves = bestMoves(board)

    bestMove = None
    i = 0
    for move in moves:
        i+=1
        

        moveBoard = board
        if(move[0] != None):
                moveBoard.update_board(move[1], move[2], move[0])
        else:
            moveBoard = board.copy()
            moveBoard.update_board(move[1],move[2], move[0])


           
        moveBoard.flipPlayer()            
        (res, _) = MinMax(moveBoard, depth+1, not isMax, minRes, maxRes, cutoff)
        moveBoard.flipPlayer()  

        
        if(move[0] != None):
            moveBoard.update_board(move[2], move[1], move[0])

        
        if(isMax):
            if(res > minRes):
                #if i am max, then always grab the best res as the min
                minRes = res
                bestMove = move

        if(not isMax):
            #Since i am min, if this res < my maxRes, i will
            #take it as it make my max lower
            if(res < maxRes):
                maxRes = res
                bestMove = move


    if(isMax):
        bestRes = minRes
    else:
        bestRes = maxRes

    if(bestRes == math.inf or bestRes == -math.inf):
        if(not isMax):
            board.flipPlayer()
        bestRes = rankBoard(board)
        if(not isMax):
            board.flipPlayer()

    return (bestRes, bestMove)





def goodCutOff(board: Board):
    num = len(board.tiles)
    if(num > 20):
        return 2

    if(num > 15):
        return 3
    
    if(num > 10):
        return 3
    
    if(num > 8):
        return 6
    
    if(num > 5):
        return 8

    return 4

def ifnomovefounduseheuristic(board: Board, res, move):
    if(rankBoard(board) == res):
        return bestMoves(board)[0]
    else:
        return move

def AIMoveMinMax1(board: Board):   
    (res, move) = AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0(board, 0, True, -math.inf, math.inf, 2)
    print(res)
    return move

def AIMoveMinMax(board: Board):    
    (res, move) = AIMoveMinMaxEvalAlphaBeta(board, 0, True, -math.inf, math.inf, 2)
    return move
    # (res, move) = AIMoveMinMaxEvalAlphaBetaQuiescensePruning(board, 0, True, -math.inf, math.inf, 2)
    # move = ifnomovefounduseheuristic(board, res, move)
    # return move



def determineMove(board):
    return AIMoveMinMax1(board)

def anotherDetermineMove(board):
    return op_alpha_beta(board) 

def determineMoveRes(board):
    return AIMoveMinMaxEvalAlphaBetaQuiescensePruningDepth0(board, 0, True, -math.inf, math.inf, 2)


